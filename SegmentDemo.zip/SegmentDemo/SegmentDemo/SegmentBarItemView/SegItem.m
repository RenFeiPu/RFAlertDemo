//
//  SegItem.m
//  InstrumentPro
//
//  Created by 浅佳科技 on 2018/12/28.
//  Copyright © 2018年 KuaiZhunCheFu. All rights reserved.
//

#import "SegItem.h"

@implementation SegItem

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
